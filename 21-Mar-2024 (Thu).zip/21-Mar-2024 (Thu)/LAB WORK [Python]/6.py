#input units from user
units=float(input("Enter units : "))
bill=0.0
#units=330
#start checking the units using if 
if units>=500:
	bill=(units-500)*8+ 100*2.5+100*1.5+100*1.2
	#		30*8+250+150+120=730
elif units>=400:
	bill=(units-400)*2.5+100*1.5+100*1.2
elif units>=300:
	bill=(units-300)*1.5+100*1.2
elif units>=200:
	bill=(units-200)*1.2
elif units>=0:
	bill=0.0
else:
	print("units value should not be negative!")

# print result
print("Your Bill Amount is Rs. : "+str(bill))