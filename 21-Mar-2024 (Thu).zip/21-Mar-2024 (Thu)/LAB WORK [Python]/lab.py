char = input("Enter the character: ")

if (char >='a' and char <='z') or (char >='A' and char <='Z'):
# if (ord(char) >= '65' and ord(char) <= '90') or (ord(char) >= '97' and ord(char) <= '122'))
    print(char, "Yes! It's an alphabet")
    
else:
    print(char, "It's not an alphabet")    
    