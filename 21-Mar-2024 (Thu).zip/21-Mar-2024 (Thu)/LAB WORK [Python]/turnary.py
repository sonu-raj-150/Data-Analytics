#write a program number is even or not 

number = int(input("Enter a number: "))

even_or_odd = "Even" if number % 2 == 0 else "Odd"

print(f"{number} is {even_or_odd}")
